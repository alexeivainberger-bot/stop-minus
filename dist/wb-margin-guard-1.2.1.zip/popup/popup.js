/* Попап настроек. Формулы — в коде расширения, справочники — данными (JSON). */
(function () {
  'use strict';

  var S = window.WbMarginStore;
  var FIELDS = ['taxPct', 'thresholdPct', 'commissionPct', 'logistics', 'packaging', 'returnCost', 'buyoutPct', 'otherCosts'];

  var taxPresets = [];
  var categories = [];

  function $(id) { return document.getElementById(id); }

  function note(text, isError) {
    var el = $('status');
    el.textContent = text;
    el.style.color = isError ? '#b02525' : '#1e7a4b';
  }

  async function loadJson(path, fallback) {
    try {
      var response = await fetch(path);
      if (!response.ok) throw new Error('HTTP ' + response.status);
      return await response.json();
    } catch (e) {
      return fallback;
    }
  }

  function fillSelect(select, items, labelOf, valueOf) {
    while (select.firstChild) select.removeChild(select.firstChild);
    items.forEach(function (item) {
      var option = document.createElement('option');
      option.value = valueOf(item);
      option.textContent = labelOf(item);
      select.appendChild(option);
    });
  }

  async function init() {
    var data = await S.load();
    var settings = data.settings;

    try {
      var taxes = await loadJson('../data/tax-presets.json', { presets: [{ id: 'usn6', name: 'УСН «Доходы»', pct: 6 }, { id: 'none', name: 'Не учитывать', pct: 0 }] });
      taxPresets = taxes.presets || [];
      var cats = await loadJson('../data/wb-commissions.json', { categories: [{ id: 'custom', name: 'Своя ставка', pct: 15 }] });
      categories = cats.categories || [];
    } catch (e) {
      note('Справочники не загрузились, работают значения по умолчанию', true);
    }

    fillSelect($('taxPreset'), taxPresets, function (p) { return p.name + ' (' + p.pct + '%)'; }, function (p) { return p.id; });
    fillSelect($('category'), categories, function (c) { return c.name + ' — ' + c.pct + '%'; }, function (c) { return c.id; });

    $('taxPreset').value = settings.taxPreset || (taxPresets[0] && taxPresets[0].id) || 'usn6';
    $('category').value = settings.categoryId || 'custom';

    FIELDS.forEach(function (field) {
      if ($(field)) $(field).value = settings[field];
    });
    $('costs').value = S.costsToText(data.costs);
    $('telemetryConsent').checked = !!settings.telemetryConsent;

    FIELDS.forEach(function (field) {
      var el = $(field);
      if (!el) return;
      el.addEventListener('change', async function () {
        var patch = {};
        patch[field] = el.value;
        await S.saveSettings(patch);
        note('Сохранено');
      });
    });

    $('taxPreset').addEventListener('change', async function () {
      var preset = taxPresets.filter(function (p) { return p.id === $('taxPreset').value; })[0];
      if (!preset) return;
      $('taxPct').value = preset.pct;
      await S.saveSettings({ taxPreset: preset.id, taxPct: preset.pct });
      note('Налог: ' + preset.pct + '%');
    });

    $('category').addEventListener('change', async function () {
      var id = $('category').value;
      var category = categories.filter(function (c) { return c.id === id; })[0];
      if (!category || id === 'custom') {
        await S.saveSettings({ categoryId: id });
        return;
      }
      $('commissionPct').value = category.pct;
      await S.saveSettings({ categoryId: id, commissionPct: category.pct });
      note('Комиссия: ' + category.pct + '% — сверь с тарифом WB');
    });

    $('costs').addEventListener('change', async function (ev) {
      await S.setCostsMap(S.textToCosts(ev.target.value));
      note('Себестоимости сохранены');
    });

    $('telemetryConsent').addEventListener('change', async function (ev) {
      await S.saveSettings({ telemetryConsent: ev.target.checked });
      note('Локальный журнал: ' + (ev.target.checked ? 'включён' : 'выключен'));
    });

    $('demo').addEventListener('click', function () {
      try {
        chrome.tabs.create({ url: chrome.runtime.getURL('demo/demo.html') });
        window.close();
      } catch (e) {
        note('Не удалось открыть демо', true);
      }
    });

    $('calibrate').addEventListener('click', async function () {
      try {
        var tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.tabs.sendMessage(tabs[0].id, { type: 'wbmg:calibrate' });
        note('Кликни по полю цены на странице');
        window.close();
      } catch (e) {
        note('Открой кабинет продавца WB и нажми ещё раз', true);
      }
    });

    $('import').addEventListener('click', function () {
      $('csv').click();
    });

    $('csv').addEventListener('change', function (ev) {
      var file = ev.target.files && ev.target.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = async function () {
        var map = S.parseCsvCosts(String(reader.result || ''));
        var count = Object.keys(map).length;
        if (!count) {
          note('В файле не нашлось пар «артикул; себестоимость»', true);
          return;
        }
        await S.setCostsMap(map);
        $('costs').value = S.costsToText(map);
        note('Импортировано позиций: ' + count);
      };
      reader.onerror = function () { note('Не удалось прочитать файл', true); };
      reader.readAsText(file, 'utf-8');
    });

    function download(name, text, mime) {
      var blob = new Blob([text], { type: (mime || 'text/plain') + ';charset=utf-8' });
      var url = URL.createObjectURL(blob);
      var link = document.createElement('a');
      link.href = url;
      link.download = name;
      document.body.appendChild(link);
      link.click();
      setTimeout(function () {
        URL.revokeObjectURL(url);
        link.remove();
      }, 1000);
    }

    $('export').addEventListener('click', async function () {
      var data = await S.load();
      var count = Object.keys(data.costs).length;
      if (!count) {
        note('Пока нет себестоимостей для экспорта', true);
        return;
      }
      download('sebestoimosti.csv', S.costsToCsv(data.costs), 'text/csv');
      note('Экспортировано позиций: ' + count);
    });

    $('backup').addEventListener('click', async function () {
      download('stop-minus-backup.json', await S.buildBackup(), 'application/json');
      note('Резервная копия сохранена');
    });

    $('restore').addEventListener('click', function () {
      $('backupFile').click();
    });

    $('backupFile').addEventListener('change', function (ev) {
      var file = ev.target.files && ev.target.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = async function () {
        try {
          var summary = await S.applyBackup(String(reader.result || ''));
          var data = await S.load();
          FIELDS.forEach(function (field) {
            if ($(field)) $(field).value = data.settings[field];
          });
          $('costs').value = S.costsToText(data.costs);
          note('Восстановлено: настроек ' + summary.settings + ', позиций ' + summary.costs);
        } catch (e) {
          note(e && e.message ? e.message : 'Не удалось восстановить копию', true);
        }
      };
      reader.onerror = function () { note('Не удалось прочитать файл', true); };
      reader.readAsText(file, 'utf-8');
    });

    $('manual').addEventListener('click', async function () {
      try {
        var tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.tabs.sendMessage(tabs[0].id, { type: 'wbmg:manual' });
        window.close();
      } catch (e) {
        note('Открой кабинет продавца WB и нажми ещё раз', true);
      }
    });
  }

  document.addEventListener('DOMContentLoaded', init);
})();
