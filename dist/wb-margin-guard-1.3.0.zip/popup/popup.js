/* Попап настроек. Формулы — в коде расширения, справочники — данными (JSON). */
(function () {
  'use strict';

  var S = window.WbMarginStore;
  var FIELDS = ['taxPct', 'thresholdPct', 'commissionPct', 'logistics', 'packaging', 'returnCost', 'buyoutPct', 'otherCosts'];

  var taxPresets = [];
  var categories = [];

  /* Редактор себестоимостей: массив строк {article, cost}. */
  var costRows = [];
  var saveTimer = null;

  function $(id) { return document.getElementById(id); }

  function note(text, isError) {
    var el = $('status');
    el.textContent = text;
    el.style.color = isError ? '#b02525' : '#1e7a4b';
  }

  async function loadJson(path, fallback) {
    try {
      var response = await fetch(path);
      if (!response.ok) throw new Error('HTTP ' + response.status);
      return await response.json();
    } catch (e) {
      return fallback;
    }
  }

  function fillSelect(select, items, labelOf, valueOf) {
    while (select.firstChild) select.removeChild(select.firstChild);
    items.forEach(function (item) {
      var option = document.createElement('option');
      option.value = valueOf(item);
      option.textContent = labelOf(item);
      select.appendChild(option);
    });
  }

  /* ---------- редактор строк ---------- */

  function normalizeArticle(value) {
    return String(value || '').replace(/\D/g, '');
  }

  function rowIsValid(row) {
    return /^\d{4,20}$/.test(row.article) && row.cost !== '' && isFinite(Number(row.cost)) && Number(row.cost) >= 0;
  }

  function duplicateArticles() {
    var seen = {};
    var dupes = {};
    costRows.forEach(function (row) {
      if (!/^\d{4,20}$/.test(row.article)) return;
      if (seen[row.article]) dupes[row.article] = true;
      seen[row.article] = true;
    });
    return dupes;
  }

  function renderCosts() {
    var list = $('costs');
    list.innerHTML = '';
    var dupes = duplicateArticles();

    costRows.forEach(function (row, index) {
      var wrap = document.createElement('div');
      wrap.className = 'cost-row';
      if (!rowIsValid(row) || dupes[row.article]) wrap.classList.add('invalid');

      var article = document.createElement('input');
      article.className = 'c-art';
      article.type = 'text';
      article.inputMode = 'numeric';
      article.placeholder = 'Артикул';
      article.value = row.article;
      article.addEventListener('input', function () {
        row.article = normalizeArticle(article.value);
        if (article.value !== row.article) article.value = row.article;
        scheduleSave();
        refreshValidity();
      });

      var cost = document.createElement('input');
      cost.className = 'c-cost';
      cost.type = 'text';
      cost.inputMode = 'decimal';
      cost.placeholder = 'Себестоимость, ₽';
      cost.value = row.cost;
      cost.addEventListener('input', function () {
        row.cost = cost.value;
        scheduleSave();
        refreshValidity();
      });

      var del = document.createElement('button');
      del.type = 'button';
      del.className = 'c-del';
      del.title = 'Удалить строку';
      del.textContent = '✕';
      del.addEventListener('click', function () {
        costRows.splice(index, 1);
        renderCosts();
        saveCosts();
      });

      wrap.appendChild(article);
      wrap.appendChild(cost);
      wrap.appendChild(del);
      list.appendChild(wrap);
    });

    updateCounter(dupes);
  }

  function updateCounter(dupes) {
    var valid = costRows.filter(rowIsValid).length;
    $('cost-count').textContent = valid + ' ' + plural(valid, ['позиция', 'позиции', 'позиций']);
    var error = $('cost-error');
    var dupeList = Object.keys(dupes || {});
    if (dupeList.length) {
      error.hidden = false;
      error.textContent = 'Повторяются артикулы: ' + dupeList.join(', ') + ' — оставь по одному.';
    } else {
      error.hidden = true;
      error.textContent = '';
    }
  }

  function refreshValidity() {
    var dupes = duplicateArticles();
    var rows = $('costs').children;
    for (var i = 0; i < rows.length; i++) {
      var row = costRows[i];
      var bad = !rowIsValid(row) || dupes[row.article];
      rows[i].classList.toggle('invalid', !!bad);
    }
    updateCounter(dupes);
  }

  function plural(n, forms) {
    var mod10 = n % 10;
    var mod100 = n % 100;
    if (mod10 === 1 && mod100 !== 11) return forms[0];
    if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return forms[1];
    return forms[2];
  }

  function scheduleSave() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveCosts, 400);
  }

  async function saveCosts() {
    var map = {};
    costRows.forEach(function (row) {
      if (rowIsValid(row)) map[row.article] = Number(row.cost);
    });
    await S.setCostsMap(map);
  }

  async function loadCosts() {
    var data = await S.load();
    costRows = Object.keys(data.costs)
      .sort(function (a, b) { return String(a).localeCompare(String(b)); })
      .map(function (article) { return { article: article, cost: String(data.costs[article]) }; });
    if (!costRows.length) costRows.push({ article: '', cost: '' });
    renderCosts();
  }

  /* ---------- инициализация ---------- */

  async function init() {
    var data = await S.load();
    var settings = data.settings;

    var taxes = await loadJson('../data/tax-presets.json', { presets: [{ id: 'usn6', name: 'УСН «Доходы»', pct: 6 }, { id: 'none', name: 'Не учитывать', pct: 0 }] });
    taxPresets = taxes.presets || [];
    var cats = await loadJson('../data/wb-commissions.json', { categories: [{ id: 'custom', name: 'Своя ставка', pct: 15 }] });
    categories = cats.categories || [];

    fillSelect($('taxPreset'), taxPresets, function (p) { return p.name + ' (' + p.pct + '%)'; }, function (p) { return p.id; });
    fillSelect($('category'), categories, function (c) { return c.name + ' — ' + c.pct + '%'; }, function (c) { return c.id; });

    $('taxPreset').value = settings.taxPreset || (taxPresets[0] && taxPresets[0].id) || 'usn6';
    $('category').value = settings.categoryId || 'custom';

    FIELDS.forEach(function (field) {
      if ($(field)) $(field).value = settings[field];
    });
    $('telemetryConsent').checked = !!settings.telemetryConsent;

    await loadCosts();

    FIELDS.forEach(function (field) {
      var el = $(field);
      if (!el) return;
      el.addEventListener('change', async function () {
        var patch = {};
        patch[field] = el.value;
        await S.saveSettings(patch);
        note('Сохранено');
      });
    });

    $('taxPreset').addEventListener('change', async function () {
      var preset = taxPresets.filter(function (p) { return p.id === $('taxPreset').value; })[0];
      if (!preset) return;
      $('taxPct').value = preset.pct;
      await S.saveSettings({ taxPreset: preset.id, taxPct: preset.pct });
      note('Налог: ' + preset.pct + '%');
    });

    $('category').addEventListener('change', async function () {
      var id = $('category').value;
      var category = categories.filter(function (c) { return c.id === id; })[0];
      if (!category || id === 'custom') {
        await S.saveSettings({ categoryId: id });
        return;
      }
      $('commissionPct').value = category.pct;
      await S.saveSettings({ categoryId: id, commissionPct: category.pct });
      note('Комиссия: ' + category.pct + '% — сверь с тарифом WB');
    });

    $('add-cost').addEventListener('click', function () {
      costRows.push({ article: '', cost: '' });
      renderCosts();
      var rows = $('costs').children;
      var last = rows[rows.length - 1];
      if (last) last.querySelector('.c-art').focus();
    });

    $('clear-costs').addEventListener('click', function () {
      if (!costRows.length) return;
      if (!window.confirm('Удалить все себестоимости?')) return;
      costRows = [{ article: '', cost: '' }];
      renderCosts();
      saveCosts();
      note('Список очищен');
    });

    $('telemetryConsent').addEventListener('change', async function (ev) {
      await S.saveSettings({ telemetryConsent: ev.target.checked });
      note('Локальный журнал: ' + (ev.target.checked ? 'включён' : 'выключен'));
    });

    $('calibrate').addEventListener('click', async function () {
      try {
        var tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.tabs.sendMessage(tabs[0].id, { type: 'wbmg:calibrate' });
        note('Кликни по полю цены на странице');
        window.close();
      } catch (e) {
        note('Открой кабинет продавца WB и нажми ещё раз', true);
      }
    });

    $('demo').addEventListener('click', function () {
      try {
        chrome.tabs.create({ url: chrome.runtime.getURL('demo/demo.html') });
        window.close();
      } catch (e) {
        note('Не удалось открыть демо', true);
      }
    });

    $('import').addEventListener('click', function () {
      $('csv').click();
    });

    $('csv').addEventListener('change', function (ev) {
      var file = ev.target.files && ev.target.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = function () {
        var map = S.parseCsvCosts(String(reader.result || ''));
        var count = Object.keys(map).length;
        if (!count) {
          note('В файле не нашлось пар «артикул; себестоимость»', true);
          return;
        }
        var merged = {};
        costRows.concat(Object.keys(map).map(function (article) { return { article: article, cost: String(map[article]) }; }))
          .forEach(function (row) {
            if (rowIsValid(row)) merged[row.article] = Number(row.cost);
          });
        costRows = Object.keys(merged).map(function (article) { return { article: article, cost: String(merged[article]) }; });
        renderCosts();
        saveCosts();
        note('Импортировано позиций: ' + count);
      };
      reader.onerror = function () { note('Не удалось прочитать файл', true); };
      reader.readAsText(file, 'utf-8');
    });

    function download(name, text, mime) {
      var blob = new Blob([text], { type: (mime || 'text/plain') + ';charset=utf-8' });
      var url = URL.createObjectURL(blob);
      var link = document.createElement('a');
      link.href = url;
      link.download = name;
      document.body.appendChild(link);
      link.click();
      setTimeout(function () {
        URL.revokeObjectURL(url);
        link.remove();
      }, 1000);
    }

    $('export').addEventListener('click', function () {
      var map = {};
      costRows.forEach(function (row) {
        if (rowIsValid(row)) map[row.article] = Number(row.cost);
      });
      var count = Object.keys(map).length;
      if (!count) {
        note('Пока нет себестоимостей для экспорта', true);
        return;
      }
      download('sebestoimosti.csv', S.costsToCsv(map), 'text/csv');
      note('Экспортировано позиций: ' + count);
    });

    $('backup').addEventListener('click', async function () {
      download('stop-minus-backup.json', await S.buildBackup(), 'application/json');
      note('Резервная копия сохранена');
    });

    $('restore').addEventListener('click', function () {
      $('backupFile').click();
    });

    $('backupFile').addEventListener('change', function (ev) {
      var file = ev.target.files && ev.target.files[0];
      if (!file) return;
      var reader = new FileReader();
      reader.onload = async function () {
        try {
          var summary = await S.applyBackup(String(reader.result || ''));
          var restored = await S.load();
          FIELDS.forEach(function (field) {
            if ($(field)) $(field).value = restored.settings[field];
          });
          await loadCosts();
          note('Восстановлено: настроек ' + summary.settings + ', позиций ' + summary.costs);
        } catch (e) {
          note(e && e.message ? e.message : 'Не удалось восстановить копию', true);
        }
      };
      reader.onerror = function () { note('Не удалось прочитать файл', true); };
      reader.readAsText(file, 'utf-8');
    });

    $('manual').addEventListener('click', async function () {
      try {
        var tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.tabs.sendMessage(tabs[0].id, { type: 'wbmg:manual' });
        window.close();
      } catch (e) {
        note('Открой кабинет продавца WB и нажми ещё раз', true);
      }
    });
  }

  document.addEventListener('DOMContentLoaded', init);
})();
